import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class vehicleOwner extends JFrame {
    private String vehicleOwnerID;
    private String firstName;
    private String lastName;
    private ArrayList<String> ownVehicleList;
    JTextField ownerIDField, firstNameField, lastNameField, makeField, modelField, vinField, residencyTimeField;

    public vehicleOwner(String vehicleOwnerID, String firstName, String lastName) {
        this.vehicleOwnerID = vehicleOwnerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.ownVehicleList = new ArrayList<>();
    }

    public String getVehicleOwnerID() {
        return vehicleOwnerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public ArrayList<String> getOwnVehicleList() {
        return ownVehicleList;
    }

    public void addVehicle(String vehicleID) {
        ownVehicleList.add(vehicleID);
    }

    public vehicleOwner() {
        setTitle("Client: Vehicle Information");

        // Sizing and Operations of the frame
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JPanel backgroundPanel = new JPanel();
        backgroundPanel.setLayout(null);
        backgroundPanel.setBackground(new Color(49, 158, 235));
        backgroundPanel.setBounds(0, 0, getWidth(), getHeight());
        add(backgroundPanel);
        
        JLabel titleLabel = new JLabel("Vehicle Information", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Cambria", Font.BOLD, 30));
        titleLabel.setBounds(150, 10, 300, 25);
        backgroundPanel.add(titleLabel);
        
        JLabel jobDescription = new JLabel("*All Fields Must be Completed*", SwingConstants.CENTER);
        jobDescription.setFont(new Font("Cambria", Font.BOLD, 15));
        jobDescription.setForeground(Color.WHITE);
        jobDescription.setBounds(150, 32, 300, 25);
        backgroundPanel.add(jobDescription);
        
        JSeparator topLine = new JSeparator();
        topLine.setBounds(1, 55, 600, 100); // width = frame width minus margins
        backgroundPanel.add(topLine);

        // Owner ID label and Text Field
        JLabel ownerIDLabel = new JLabel("Vehicle Owner ID:");
        ownerIDLabel.setBounds(50, 85, 150, 25);
        ownerIDLabel.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(ownerIDLabel);

        ownerIDField = new JTextField();
        ownerIDField.setBounds(200, 85, 300, 25);
        backgroundPanel.add(ownerIDField);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(92, 130, 150, 25);
        firstNameLabel.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setBounds(200, 130, 300, 25);
        backgroundPanel.add(firstNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(95, 175, 150, 25);
        lastNameLabel.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(lastNameLabel);

        lastNameField = new JTextField();
        lastNameField.setBounds(200, 175, 300, 25);
        backgroundPanel.add(lastNameField);

        JLabel makeLabel = new JLabel("Make:");
        makeLabel.setBounds(130, 220, 190, 25);
        makeLabel.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(makeLabel);

        makeField = new JTextField();
        makeField.setBounds(200, 220, 300, 25);
        backgroundPanel.add(makeField);

        JLabel modelLabel = new JLabel("Model:");
        modelLabel.setBounds(125, 265, 150, 25);
        modelLabel.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(modelLabel);

        modelField = new JTextField();
        modelField.setBounds(200, 265, 300, 25);
        backgroundPanel.add(modelField);

        JLabel vinLabel = new JLabel("VIN:");
        vinLabel.setBounds(142, 310, 150, 25);
        vinLabel.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(vinLabel);

        vinField = new JTextField();
        vinField.setBounds(200, 310, 300, 25);
        backgroundPanel.add(vinField);

        JLabel residencyTimeLabel = new JLabel("Residency Time:");
        residencyTimeLabel.setBounds(58, 350, 150, 25);
        residencyTimeLabel.setFont(new Font("Cambria", Font.BOLD, 15));

        JLabel residencyTime2Label = new JLabel("(mm-dd-yyyy)");
        residencyTime2Label.setBounds(70, 365, 150, 25);
        residencyTime2Label.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(residencyTimeLabel);
        backgroundPanel.add(residencyTime2Label);

        residencyTimeField = new JTextField();
        residencyTimeField.setBounds(200, 355, 300, 25);
        backgroundPanel.add(residencyTimeField);
        
        //bottom line
        JSeparator bottomLine = new JSeparator();
        bottomLine.setBounds(1, 400, 600, 100);
        backgroundPanel.add(bottomLine);

        // Submit Button
        JButton submitButton = new JButton("Submit");
        submitButton.setBounds(250, 415, 100, 30);
        submitButton.setFont(new Font("Cambria", Font.BOLD, 14));
        backgroundPanel.add(submitButton);

        submitButton.addActionListener(e -> saveVehicleInfo());

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setBounds(30, 415, 100, 30);
        backButton.setFont(new Font("Cambria", Font.BOLD, 14));
        backgroundPanel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the current window
                new Client();
            }
        });

        setVisible(true);
    }

    private void saveVehicleInfo() {
        String ownerID = ownerIDField.getText().trim();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String make = makeField.getText().trim();
        String model = modelField.getText().trim();
        String vin = vinField.getText().trim();
        String residencyTime = residencyTimeField.getText().trim();
        
      
        // Pop-up customization
        UIManager.put("OptionPane.messageForeground", new Color(23, 50, 180)); // Font color
        UIManager.put("Button.background", new Color(220, 230, 250)); // Button color
        UIManager.put("Button.foreground", Color.BLACK);              // Button text color
   
        
        if (ownerID.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || make.isEmpty() || model.isEmpty()
                || vin.isEmpty() || residencyTime.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled correctly!", "Vehicle Owner - Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Simulating communication with the server to accept or reject data
        JOptionPane.showMessageDialog(this,
                "Submitting your information...\nPlease wait for the Cloud Controller to respond.", " Vehicle Owner - Submitting",
                JOptionPane.INFORMATION_MESSAGE);

        try (Socket socket = new Socket("localhost", 1234);
             DataOutputStream out2 = new DataOutputStream(socket.getOutputStream());
             DataInputStream input = new DataInputStream(socket.getInputStream());)


        {

            out2.writeUTF("Vehicle");
            out2.writeUTF(ownerID);
            out2.writeUTF(firstName);
            out2.writeUTF(lastName);
            out2.writeUTF(make);
            out2.writeUTF(model);
            out2.writeUTF(vin);
            out2.writeUTF(residencyTime);
            out2.flush();
            String testInput = input.readUTF();
            System.out.print(testInput);

            JOptionPane.showMessageDialog(this,
                    "Your Data has been "+ testInput, testInput+"!",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error connecting to server: " + ex.getMessage(), "Connection Error",
                    JOptionPane.ERROR_MESSAGE);
        }

        // Clear the fields
        ownerIDField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        makeField.setText("");
        modelField.setText("");
        vinField.setText("");
        residencyTimeField.setText("");

    }
}
