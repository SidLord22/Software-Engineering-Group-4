import javax.sound.sampled.Line;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Launcher extends JFrame {
    public Launcher() {
    	
        setTitle("VCRTS"); // Window Title (Top Left Corner)
        setSize(600, 400); // Size of Frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When Exit, Frame Closes
        setLocationRelativeTo(null); // Sets Frame to the Middle
        setLayout(null); // Layout is Blank (null)

        // Background Panel
        JPanel backgroundPanel = new JPanel();
        backgroundPanel.setLayout(null);
        backgroundPanel.setBackground(new Color(49, 158, 235));
        backgroundPanel.setBounds(0, 0, getWidth(), getHeight());
        add(backgroundPanel);

        // Welcome Title
        JLabel titleLabel = new JLabel("Welcome", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Cambria", Font.BOLD, 40));
        titleLabel.setBounds(150, 10, 300, 50);
        backgroundPanel.add(titleLabel);
        
     // Horizontal line below "Welcome"
        JSeparator topLine = new JSeparator();
        topLine.setBounds(1, 65, 600, 400); // width = frame width minus margins
        backgroundPanel.add(topLine);
        
        
        // Select Role
        JLabel selectRole = new JLabel("Select Client or Server:");
        selectRole.setFont(new Font("Cambria", Font.BOLD, 20));
        selectRole.setBounds(200, 90, 300, 100);
        backgroundPanel.add(selectRole);

        //Client Button
        JButton clientButton = new JButton("Client");
        clientButton.setBounds(320, 170, 150, 40);
        clientButton.setFont(new Font("Cambria",Font.BOLD, 15));
        backgroundPanel.add(clientButton);

        //Server Button
        JButton serverButton = new JButton("Server");
        serverButton.setBounds(130, 170, 150, 40);
        serverButton.setFont(new Font("Cambria", Font.BOLD, 15));
        backgroundPanel.add(serverButton);

        // When User Clicks Client Button
        clientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Client(); // Opens the Client Frame
            }
        });

        // When User Clicks Server Button
        serverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new cloudController(); // Opens the CloudController Frame
            }
        });
        
     // Horizontal line below the paragraph
        JSeparator bottomLine = new JSeparator();
        bottomLine.setBounds(1, 290, 600, 100);
        backgroundPanel.add(bottomLine);
        
        // Description 
        JLabel description = new JLabel("Vehicular Cloud Computing is a concept that combines cloud computing and");
        description.setFont(new Font("Cambria", Font.BOLD, 15));
        description.setForeground(Color.WHITE);
        description.setBounds(30, 260, 600, 100);
        backgroundPanel.add(description);
       
        JLabel description2 = new JLabel("vehicular networks, where modern vehicles act as mobile computing resources to");
        description2.setFont(new Font("Cambria", Font.BOLD, 15));
        description2.setForeground(Color.WHITE);
        description2.setBounds(10, 275, 600, 100);
        backgroundPanel.add(description2);
        
        JLabel description3 = new JLabel("support dynamic and static applications like traffic managment & disaster response.");
        description3.setFont(new Font("Cambria", Font.BOLD, 15));
        description3.setForeground(Color.WHITE);
        description3.setBounds(4, 290, 600, 100);
        backgroundPanel.add(description3);
        
       
    }

}