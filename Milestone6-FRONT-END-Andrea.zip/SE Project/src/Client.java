import javax.swing.*;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.plaf.basic.BasicComboBoxUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Client extends JFrame{
	
    JButton loginButton;

	
	public Client() {
		setTitle("VCRTS");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
        JPanel backgroundPanel = new JPanel();
        backgroundPanel.setLayout(null);
        backgroundPanel.setBackground(new Color(49, 158, 235));
        backgroundPanel.setBounds(0, 0, getWidth(), getHeight());
        add(backgroundPanel);
        
        JLabel titleLabel = new JLabel("Client Page", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Cambria", Font.BOLD, 40));
        titleLabel.setBounds(150, 20, 300, 50);
        backgroundPanel.add(titleLabel);
        
        JLabel titleLabel2 = new JLabel("Select Your Role", SwingConstants.CENTER);
        titleLabel2.setFont(new Font("Cambria", Font.BOLD, 20));
        titleLabel2.setBounds(150, 100, 300, 50);
        backgroundPanel.add(titleLabel2);
        
        
        JComboBox<String> roleDropdown = new JComboBox<>(new String[]{"Vehicle Owner", "Job Owner"});
        roleDropdown.setBounds(225, 150, 150, 40);
        roleDropdown.setFont(new Font("Cambria", Font.BOLD, 17));
        roleDropdown.setBackground(Color.WHITE);
        roleDropdown.setForeground(new Color(23,25,252));
        roleDropdown.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        backgroundPanel.add(roleDropdown);
        
     
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(250, 210, 100, 35);
        loginButton.setFont(new Font("Cambria", Font.BOLD, 14));
        backgroundPanel.add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                String selectedItem = (String) roleDropdown.getSelectedItem();
                if (selectedItem.equals("Vehicle Owner")) {
                    new vehicleOwner();
                } else if(selectedItem.equals("Job Owner")) {
                    new jobOwner();
                
            }
            }});
        
         
        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 320, 100, 30);
        backButton.setFont(new Font("Cambria", Font.BOLD, 14));
        backgroundPanel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the current window
                new Launcher();
            }
        });
        
        
        setVisible(true);
	}
	
}