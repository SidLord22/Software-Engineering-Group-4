import javax.sound.sampled.Line;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Launcher extends JFrame {
    public Launcher() {
    	
        setTitle("VCRTS"); // Window Title (Top Left Corner)
        setSize(600, 400); // Size of Frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When Exit, Frame Closes
        setLocationRelativeTo(null); // Sets Frame to the Middle
        setLayout(null); // Layout is Blank (null)

        // Background Panel
        JPanel backgroundPanel = new JPanel();
        backgroundPanel.setLayout(null);
        backgroundPanel.setBackground(new Color(49, 158, 235));
        backgroundPanel.setBounds(0, 0, getWidth(), getHeight());
        add(backgroundPanel);

        // Welcome Title
        JLabel titleLabel = new JLabel("Welcome", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Cambria", Font.BOLD, 40));
        titleLabel.setBounds(150, 20, 300, 50);
        backgroundPanel.add(titleLabel);
        
        // Description 
        JLabel description = new JLabel("Vehicular Cloud Computing is a concept that combines");
        description.setFont(new Font("Courier New", Font.BOLD, 15));
        description.setForeground(Color.WHITE);
        description.setBounds(70, 40, 500, 100);
        backgroundPanel.add(description);
       
        JLabel description2 = new JLabel("cloud computing and vehicular networks, where modern");
        description2.setFont(new Font("Courier New", Font.BOLD, 15));
        description2.setForeground(Color.WHITE);
        description2.setBounds(70, 55, 500, 100);
        backgroundPanel.add(description2);
        
        JLabel description3 = new JLabel("vehicles act as mobile computing resources to support");
        description3.setFont(new Font("Courier New", Font.BOLD, 15));
        description3.setForeground(Color.WHITE);
        description3.setBounds(70, 70, 500, 100);
        backgroundPanel.add(description3);
        
        JLabel description4 = new JLabel("dynamic and static applications like traffic management");
        description4.setFont(new Font("Courier New", Font.BOLD, 15));
        description4.setForeground(Color.WHITE);
        description4.setBounds(60, 85, 500, 100);
        backgroundPanel.add(description4);
        
        JLabel description5 = new JLabel("and disaster response.");
        description5.setFont(new Font("Courier New", Font.BOLD, 15));
        description5.setForeground(Color.WHITE);
        description5.setBounds(220, 100, 500, 100);
        backgroundPanel.add(description5);
        
        // Select Role
        JLabel selectRole = new JLabel("Select Client or Server:");
        selectRole.setFont(new Font("Cambria", Font.BOLD, 20));
        selectRole.setBounds(200, 150, 300, 100);
        backgroundPanel.add(selectRole);

        //Client Button
        JButton clientButton = new JButton("Client");
        clientButton.setBounds(320, 225, 150, 50);
        clientButton.setFont(new Font("Verdana",Font.PLAIN, 15));
        backgroundPanel.add(clientButton);

        //Server Button
        JButton serverButton = new JButton("Server");
        serverButton.setBounds(120, 225, 150, 50);
        serverButton.setFont(new Font("Verdana",Font.PLAIN, 15));
        backgroundPanel.add(serverButton);

        // When User Clicks Client Button
        clientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Client(); // Opens the Client Frame
            }
        });

        // When User Clicks Server Button
        serverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new cloudController(); // Opens the CloudController Frame
            }
        });
    }

}