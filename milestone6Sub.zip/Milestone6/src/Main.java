public class Main {

    public static void main(String[] args) {
        new Launcher().setVisible(true);
        //new Launcher();
    }
}
