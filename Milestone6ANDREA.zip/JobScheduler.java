import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

class JobCollect {
    String jobName;
    int jobID;
    int jobDuration;
    int deadline;
    String timestamp;
    int completionTime;

    public JobCollect(String jobName, int jobID, int jobDuration, int deadline, String timestamp) {
        this.jobName = jobName;
        this.jobID = jobID;
        this.jobDuration = jobDuration;
        this.deadline = deadline;
        this.timestamp = timestamp;
    }
}

public class JobScheduler {
	public static Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/vcrts"; // Change DB name as needed
        String user = "root"; // your DB username
        String password = ""; // your DB password

        return DriverManager.getConnection(url, user, password);
    }

    public static ArrayList<Job> getJobs() {
        ArrayList<Job> jobs = new ArrayList<>();

        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM jobs")) {

            while (rs.next()) {
                String jobID = rs.getString("jobID");
                String jobName = rs.getString("jobName");
                String description = rs.getString("description");
                String deadline = rs.getString("deadline");
                String jobOwnerID = rs.getString("jobOwnerID");
                int jobDuration = rs.getInt("jobDuration");
                int redundancyLevel = rs.getInt("redundancyLevel");

                Job job = new Job(jobID, jobName, description, deadline, jobOwnerID, jobDuration, redundancyLevel);
                jobs.add(job);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return jobs;
    }
}