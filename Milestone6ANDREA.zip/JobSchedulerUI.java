import javax.swing.*;
import java.awt.*;
import java.util.List;

public class JobSchedulerUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Cloud Controller - Job Records");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 500);

            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            List<Job> jobs = JobScheduler.getJobs();

            if (jobs.isEmpty()) {
                panel.add(new JLabel("No job data available."));
            } else {
                for (Job job : jobs) {
                    JPanel jobPanel = new JPanel(new GridLayout(7, 1));
                    jobPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                    jobPanel.add(new JLabel("Job ID: " + job.getJobID()));
                    jobPanel.add(new JLabel("Job Name: " + job.getJobName()));
                    jobPanel.add(new JLabel("Description: " + job.getDescription()));
                    jobPanel.add(new JLabel("Deadline: " + job.getDeadline()));
                    jobPanel.add(new JLabel("Duration: " + job.getJobDuration() + " hrs"));
                    jobPanel.add(new JLabel("Redundancy Level: " + job.getRedundancyLevel()));
                    jobPanel.add(new JLabel("Owner ID: " + job.getJobOwnerID()));
                    panel.add(jobPanel);
                }
            }

            frame.add(new JScrollPane(panel));
            frame.setVisible(true);
        });
    }
}