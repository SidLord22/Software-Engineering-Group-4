import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class JobSchedulerUI {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            JFrame frame = new JFrame("Cloud Controller - Job Records");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(500, 500);
            frame.setLayout(new BorderLayout());

           
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            List<JobCollect> jobs = JobScheduler.getJobs();

            if (jobs.isEmpty()) {
                JLabel noJobsLabel = new JLabel("No job data available.");
                noJobsLabel.setHorizontalAlignment(SwingConstants.CENTER);
                noJobsLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
                frame.add(noJobsLabel, BorderLayout.NORTH); 
            } else {
                for (JobCollect job : jobs) {
                    JPanel jobPanel = new JPanel(new GridLayout(5, 1));
                    jobPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                    jobPanel.add(new JLabel("Job ID: " + job.jobID));
                    jobPanel.add(new JLabel("Job Name: " + job.jobName));
                    jobPanel.add(new JLabel("Deadline: " + job.deadline));
                    jobPanel.add(new JLabel("Duration: " + job.jobDuration + " mins"));
                    jobPanel.add(new JLabel("Timestamp: " + job.timestamp));
                    panel.add(jobPanel);
                    panel.add(Box.createVerticalStrut(10)); // Add spacing between jobs
                }
            }

            
            JScrollPane scrollPane = new JScrollPane(panel);
            frame.add(scrollPane, BorderLayout.CENTER);

            
            JButton goToSchedulerButton = new JButton("Click Me");
            goToSchedulerButton.setPreferredSize(new Dimension(120, 40));
            goToSchedulerButton.setFont(new Font("Verdana", Font.BOLD, 14));
            goToSchedulerButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frame.dispose(); // Close current frame
                    new JobSchedulerFrame(); // Open the new frame
                }
            });

            JPanel buttonPanel = new JPanel(); 
            buttonPanel.add(goToSchedulerButton);
            frame.add(buttonPanel, BorderLayout.SOUTH); 

            
            
            frame.setVisible(true);
        });
    }
}