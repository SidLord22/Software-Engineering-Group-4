import javax.sound.sampled.Line;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JobSchedulerFrame extends JFrame{
	public JobSchedulerFrame() {
		
		setTitle("VCRTS"); // Window Title (Top Left Corner)
        setSize(600, 400); // Size of Frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When Exit, Frame Closes
        setLocationRelativeTo(null); // Sets Frame to the Middle
        setLayout(null); // Layout is Blank (null)
        
        
        JPanel backgroundPanel = new JPanel();
        backgroundPanel.setLayout(null);
        backgroundPanel.setBackground(new Color(49, 158, 235));
        backgroundPanel.setBounds(0, 0, getWidth(), getHeight());
        add(backgroundPanel);

        // Welcome Title
        JLabel titleLabel = new JLabel("Welcome To Job Scheduler Frame", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Cambria", Font.BOLD, 15));
        titleLabel.setBounds(150, 20, 300, 50);
        backgroundPanel.add(titleLabel);
        
        
        
        setVisible(true);
		
	}
	

}
