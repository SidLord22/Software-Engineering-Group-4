public class Main {

    public static void main(String[] args) {
        new Launcher().setVisible(true);

        // This connects to the database in order to pull the data
        cloudController.connectToDatabase();

        // This calls the method to print the data
        cloudController.printCumulativeJobDurations();
    }
}
