
//Sorry to whoever made this class, I used it to test if I am able to connect to MySQL -JIN
public class viewVehicles {
    public static void main(String[] args) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded in successfully");
        } catch (ClassNotFoundException e){
            System.out.println("Could not load in MySQL driver");
        }
    }

}
